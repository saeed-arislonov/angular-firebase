export const environment = {
  production: true,
  firebase : {
    apiKey: 'AIzaSyAukQIkg4Z8MXvTGSksUP0m_DfNeSzn3LA',
    authDomain: 'clientpanel-8e5cf.firebaseapp.com',
    databaseURL: 'https://clientpanel-8e5cf.firebaseio.com',
    projectId: 'clientpanel-8e5cf',
    storageBucket: 'clientpanel-8e5cf.appspot.com',
    messagingSenderId: '85119031400'
  }
};
